<?php


header("location: /");
?>