<?php
//
//SC	:	roamerimei.xyz
//Dev	:	scardflasher
//By	:	scard-project
//Email	:	scard-project.id 
//
//▪ http://scard-project.id 
//▪ http://youtube.com/c/scard-project
//▪ http://instagram.com/scard-project
//▪ http://facebook.com/scard-project
//
//Hak cipta 2017-2021
//Terakhir dikembangkan Februari 2021
//Dilarang menjual/membagikan script KM Panel. Serta mengubah/menghapus copyright ini!
//

header("location: /");
?>