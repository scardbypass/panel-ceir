<?php
header("location: /");
?>