<?php


header("location: /");
?>