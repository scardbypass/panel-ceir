-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 31 Agu 2024 pada 08.59
-- Versi server: 10.6.18-MariaDB-cll-lve-log
-- Versi PHP: 8.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scardfla_ceir`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `berita`
--

CREATE TABLE `berita` (
  `id` int(10) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `tipe` enum('INFORMASI','PERINGATAN','PENTING','LAYANAN','PERBAIKAN') NOT NULL,
  `subjek` text NOT NULL,
  `konten` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data untuk tabel `berita`
--

INSERT INTO `berita` (`id`, `date`, `time`, `tipe`, `subjek`, `konten`) VALUES
(12, '2020-07-25', '00:10:31', 'INFORMASI', 'Cara Deposit di Kitadigital SMM Panel Menggunakan GoPay', 'Video ini berisi Panduan Deposit di SMM Panel Kitadigital menggunakan GoPay melalui SMS Banking Bank BNI. Sebenarnya Anda juga bisa melakukan pembayaran langsung dari Aplikasi Gojek, tetapi pada panduan kali ini saya menggunakan SMS Banking untuk transfer nya ke Akun Gopay.\n\nVideo Tutorial : https://www.youtube.com/watch?v=eFBcVEwiID8\n\nAkses layanan gratis untuk semua pengguna dengan sistem penambahan saldo gratis dan giveaway dari Kitadigital. Lama waktu layanan gratis Kitadigital berlaku sesuai aturan yang ditetapkan. Lihat informasi layanan gratis terupdate di halaman Aktivasi Layanan Gratis Kitadigital https://kitadigital.id/blog/\n\nSMM Panel Kitadigital adalah Website yang Menyediakan Produk &amp;amp;amp; Layanan Pemasaran Sosial Media / Social Media Marketing, Sistem Payment Point Online Bank (PPOB), Layanan Pembayaran Elektronik, Layanan Optimalisasi Toko Online, Voucher Game &amp;amp;amp; Produk Digital Lainnya.\n\nLebih dari 1000+ layanan yang disediakan kitadigital.id bisa Anda dapatkan pada halaman Produk dan Layanan https://kitadigital.id/halaman/daftar-harga\n\n'),
(14, '2020-07-25', '15:26:29', 'PENTING', 'Login Pengguna di Perangkat Mobile dalam Tahap Perbaikan', 'Untuk akses login Pengguna Kitadigital di Perangkat Mobile (Android &amp;amp; iOS) masih dalam Tahap Perbaikan.\r\n\r\nSementara untuk Login di Perangkat Desktop masih berjalan dengan Baik.\r\n\r\nTerima kasih'),
(15, '2020-07-25', '18:18:03', 'INFORMASI', 'Peluncuran Kitadigital dan Harga', 'Semua harga produk &amp;amp;amp; layanan kami perbaharui setelah peluncuran sistem aplikasi berbasis beb dan android ke publik secara resmi pada bulan Agustus 2020.\r\n\r\nUntuk saat ini aplikasi web Kitadigital masih dalam tahap pengembangan versi. Kami belum sepenuhnya menerima pesanan.'),
(16, '2020-07-25', '18:22:11', 'PENTING', 'Orderan Produk dan Jasa Layanan', 'Kami hanya mengaktifkan fitur deposit saja saat ini. Orderan produk dan jasa layanan masih dalam pengembangan.\r\n\r\nSemua Fitur Kitadigital yang Tersedia akan diaktifkan setelah peluncuran Web dan Aplikasi Android Kitadigital pada bulan Agustus 2020.'),
(17, '2020-07-25', '18:31:18', 'INFORMASI', 'Metode Pembayaran yang Tersedia', 'Untuk saat ini kami menerima 3 jenis sistem pembayaran:\r\n1. Bank\r\n2. E-Payment\r\n3. Pulsa\r\n\r\nMetode pembayaran:\r\n1. BNI Transfer\r\n2. BRI Transfer\r\n3. Dana Transfer\r\n4. Gopay Transfer\r\n5. OVO Transfer\r\n6. Telkomsel Transfer\r\n\r\nMetode konfirmasi pembayaran\r\n1. Otomatis\r\n2. Manual\r\n\r\nSemua Fitur dan Layanan Kitadigital akan diperbaharui setelah peluncuran Web dan Aplikasi Android pada bulan Agustus 2020.'),
(18, '2020-07-31', '15:00:59', 'LAYANAN', 'Fitur Tarik Saldo ke E-Money Telah Tersedia', 'Sekarang kamu bisa tarik saldo di akunmu dengan metode pembayaran ke e-money, seperti:\r\n1. LinkAja\r\n2. MANDIRI E-TOLL\r\n3. OVO\r\n4. SHOPEE PAY\r\n5. TAPCASH BNI\r\n6. TIX ID\r\n7. DANA\r\n8. dan GO PAY\r\n\r\nSilahkan menuju ke halaman https://kitadigital.id/pemesanan/e-money\r\n\r\n- Customer support Kitadigital'),
(22, '2020-08-16', '13:47:16', 'LAYANAN', 'Sistem Telah Kembali Normal', 'Sistem Telah Kembali Normal. Selamat Bertransaksi..'),
(23, '2020-08-16', '13:48:12', 'INFORMASI', 'Produk dan Layanan Telah Tersedia Kembali', 'Semua Produk dan Layanan Kembali Normal '),
(24, '2020-08-16', '13:49:54', 'LAYANAN', 'Perawatan Sistem (Maintenance) Telah Berakhir', 'Semua Produk dan Layanan Telah kembali Normal'),
(25, '2020-08-17', '12:16:35', 'PERINGATAN', 'Dirgahayu Republik Indonesia', '17 Agustus 1945 - 17 Agustus 2020. &amp;amp;amp;amp;amp;amp;quot;Kemerdekaan bukan tanda untuk berhenti berjuang, tapi tanda untuk berjuang lebih keras dan lebih maju, selamat Hari Kemerdekaan ke-75 RI untuk Rakyat Indonesia&amp;amp;amp;amp;amp;amp;quot;\r\n\r\nGo Ahead Indonesiaku'),
(26, '2020-08-20', '838:59:59', 'LAYANAN', 'Semua Produk Kembali Normal', 'Semua produk dan jasa layanan di KM panel telah kembali normal seperti biasanya. Selamat menikmati layanan kami.\r\n\r\n- KM Panel'),
(27, '2020-09-04', '00:00:00', 'PERINGATAN', 'Peringatan Kembali mengenai Layanan Auto Follower', 'Data statistik kami menunjukkan 27% pengguna auto follower tidak menggunakan akun publik. Oleh sebab itu kami ingatkan kembali untuk merubah status privasi akun ke publik agar layanan auto follower dapat bekerja seperti normalnya. Terima kasih');

-- --------------------------------------------------------

--
-- Struktur dari tabel `deposit`
--

CREATE TABLE `deposit` (
  `id` int(10) NOT NULL,
  `kode_deposit` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `tipe` varchar(255) NOT NULL,
  `provider` varchar(255) NOT NULL,
  `payment` varchar(250) NOT NULL,
  `nomor_pengirim` varchar(250) NOT NULL,
  `tujuan` varchar(50) NOT NULL,
  `jumlah_transfer` int(255) NOT NULL,
  `get_saldo` varchar(250) NOT NULL,
  `status` enum('Success','Pending','Error','') NOT NULL,
  `place_from` varchar(50) NOT NULL DEFAULT 'WEB',
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `deposit_bank`
--

CREATE TABLE `deposit_bank` (
  `id` int(10) NOT NULL,
  `kode_deposit` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `tipe` varchar(255) NOT NULL,
  `provider` varchar(255) NOT NULL,
  `payment` varchar(250) NOT NULL,
  `nomor_pengirim` varchar(250) NOT NULL,
  `tujuan` varchar(50) NOT NULL,
  `jumlah_transfer` int(255) NOT NULL,
  `get_saldo` varchar(250) NOT NULL,
  `status` enum('Success','Pending','Error','') NOT NULL,
  `place_from` varchar(50) NOT NULL DEFAULT 'WEB',
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `deposit_emoney`
--

CREATE TABLE `deposit_emoney` (
  `id` int(10) NOT NULL,
  `kode_deposit` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `tipe` varchar(255) NOT NULL,
  `provider` varchar(255) NOT NULL,
  `payment` varchar(250) NOT NULL,
  `nomor_pengirim` varchar(250) NOT NULL,
  `tujuan` varchar(50) NOT NULL,
  `jumlah_transfer` int(255) NOT NULL,
  `get_saldo` varchar(250) NOT NULL,
  `status` enum('Success','Pending','Error','') NOT NULL,
  `place_from` varchar(50) NOT NULL DEFAULT 'WEB',
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `deposit_epayment`
--

CREATE TABLE `deposit_epayment` (
  `id` int(10) NOT NULL,
  `kode_deposit` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `tipe` varchar(255) NOT NULL,
  `provider` varchar(255) NOT NULL,
  `payment` varchar(250) NOT NULL,
  `nomor_pengirim` varchar(250) NOT NULL,
  `tujuan` varchar(50) NOT NULL,
  `jumlah_transfer` int(255) NOT NULL,
  `get_saldo` varchar(250) NOT NULL,
  `status` enum('Success','Pending','Error','') NOT NULL,
  `place_from` varchar(50) NOT NULL DEFAULT 'WEB',
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `deposit_tsel`
--

CREATE TABLE `deposit_tsel` (
  `id` int(10) NOT NULL,
  `kode_deposit` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `tipe` varchar(255) NOT NULL,
  `provider` varchar(255) NOT NULL,
  `payment` varchar(250) NOT NULL,
  `nomor_pengirim` varchar(250) NOT NULL,
  `tujuan` varchar(50) NOT NULL,
  `jumlah_transfer` int(255) NOT NULL,
  `get_saldo` varchar(250) NOT NULL,
  `status` enum('Success','Pending','Error','') NOT NULL,
  `place_from` varchar(50) NOT NULL DEFAULT 'WEB',
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `deposit_voucher`
--

CREATE TABLE `deposit_voucher` (
  `id` int(10) NOT NULL,
  `kode_deposit` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `tipe` varchar(255) NOT NULL,
  `provider` varchar(255) NOT NULL,
  `payment` varchar(250) NOT NULL,
  `nomor_pengirim` varchar(250) NOT NULL,
  `tujuan` varchar(50) NOT NULL,
  `jumlah_transfer` int(255) NOT NULL,
  `get_saldo` varchar(250) NOT NULL,
  `status` enum('Success','Pending','Error','') NOT NULL,
  `place_from` varchar(50) NOT NULL DEFAULT 'WEB',
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `edit_sn`
--

CREATE TABLE `edit_sn` (
  `id` int(11) NOT NULL,
  `msg` text NOT NULL,
  `layanan` text NOT NULL,
  `type` enum('all','particular') NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `halaman`
--

CREATE TABLE `halaman` (
  `id` int(2) NOT NULL,
  `konten` text NOT NULL,
  `update_terakhir` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `halaman`
--

INSERT INTO `halaman` (`id`, `konten`, `update_terakhir`) VALUES
(1, '<div class=\"text-center\">\r\nPlatform Layanan Digital All in One, Berkualitas, Cepat & Aman. Menyediakan Produk & Layanan Pemasaran Sosial Media, Payment Point Online Bank, Layanan Pembayaran Elektronik, Optimalisasi Toko Online, Voucher Game dan Produk Digital\r\n</div>', '2019-01-21 00:00:00'),
(2, '<div class=\"text-center\">\r\nPlatform Kitadigital menyediakan berbagai layanan Sosial Media Instagram, Facebook, Whatsapp, Twitter, Pinterest, Tiktok, Youtube, SoundCloud dan Spotify. Juga terdapat fitur optimasi toko online Shopee, Bukalapak dan Tokopedia.<br/><br/>\r\nUntuk pembayaran dan transaksi, Kitadigital menyediakan berbagai metode termasuk Payment Point Online Bank (PPOB) untuk Pembayaran Tagihan & Pembelian Produk Digital seperti Pulsa, Internet, Token PLN, Saldo Gopay/Grabpay, Voucher, E-money, dan Cryptocurrency.\r\n</div>', '2019-01-21 00:00:00'),
(3, '<div class=\"text-center\">\r\nBerikut adalah daftar layanan jasa Sosial Media, Toko Online, Payment Point Online Bank (PPOB), dan berbagai produk virtual yang tersedia di Kitadigital.\r\n</div>', '2019-01-21 00:00:00'),
(4, '<div class=\"text-center\">\r\nBerikut adalah daftar partner dan jaringan kerjasama kami yang telah terdaftar.\r\n</div>', '2019-01-21 00:00:00'),
(5, '<div class=\"text-center\">\r\nPlatform Kitadigital menyediakan berbagai fitur pada layanan jasa dan penjualan produk, adapun fitur & teknologi yang mendukung dibalik Aplikasi Kitadigital dapat anda lihat pada halaman dibawah.<br/><br/>\r\nFitur unggulan dan teknologi yang mendukung ini tentunya adalah bagian dari Platform Kitadigital yang telah memberi dukungan penyimpanan dan pengelolaan data, cloud web hosting, metode algoritma, sistem pembayaran, e-payment, dan lainnya yang akan terus kami tingkatkan kualitasnya.\r\n</div>', '2019-01-21 00:45:00'),
(6, '<div class=\"text-center\">\r\nKitadigital menyediakan berbagai metode pembayaran, mulai dari Voucher Deposit, Transfer Pulsa, Cryptocurrency, E-Money Lokal & Global, hingga Bank Transfer.\r\n</div>', '2020-08-10 21:13:06');

-- --------------------------------------------------------

--
-- Struktur dari tabel `harga_pendaftaran`
--

CREATE TABLE `harga_pendaftaran` (
  `id` int(2) NOT NULL,
  `level` varchar(50) NOT NULL,
  `harga` double NOT NULL,
  `bonus` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `harga_pendaftaran`
--

INSERT INTO `harga_pendaftaran` (`id`, `level`, `harga`, `bonus`) VALUES
(1, 'Member', 0, 0),
(2, 'Agen', 0, 0),
(3, 'Reseller', 0, 0),
(4, 'Admin', 0, 0),
(5, 'Developers', 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `history_saldo`
--

CREATE TABLE `history_saldo` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `aksi` enum('Penambahan Saldo','Pengurangan Saldo') NOT NULL,
  `nominal` double NOT NULL,
  `pesan` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `history_saldo`
--

INSERT INTO `history_saldo` (`id`, `username`, `aksi`, `nominal`, `pesan`, `date`, `time`) VALUES
(50, 'ronidwipriyatna', 'Pengurangan Saldo', 1599.675, 'Order ID 5264619 Produk PPOB', '2023-07-11', '13:13:18'),
(51, 'ronidwipriyatna', 'Penambahan Saldo', 1599.675, 'Pengembalian Dana. Order ID 5264619', '2023-07-11', '13:16:01'),
(52, 'admin', 'Pengurangan Saldo', 30000, 'Order ID 8539473 Produk PPOB', '2024-05-26', '17:36:38'),
(53, 'admin', 'Pengurangan Saldo', 30000, 'Order ID 8708620 Produk PPOB', '2024-05-26', '17:37:27'),
(54, 'admin', 'Pengurangan Saldo', 30000, 'Order ID 5593186 Produk PPOB', '2024-05-26', '17:46:19'),
(55, 'admin', 'Pengurangan Saldo', 7000, 'Order ID 3247241 Produk PPOB', '2024-05-26', '17:49:57'),
(56, 'admin', 'Pengurangan Saldo', 7000, 'Order ID 3080296 Produk PPOB', '2024-05-26', '17:58:49'),
(57, 'admin', 'Pengurangan Saldo', 7000, 'Order ID 6405932 Produk PPOB', '2024-05-27', '15:20:44'),
(58, 'maranzano', 'Pengurangan Saldo', 1400, 'Order ID 8722197 Produk PPOB', '2024-08-13', '20:36:58'),
(59, 'maranzano', 'Pengurangan Saldo', 1400, 'Order ID 0064391 Produk PPOB', '2024-08-13', '20:42:31'),
(60, 'scardflasher2', 'Pengurangan Saldo', 1400, 'Order ID 3363175 Produk PPOB', '2024-08-13', '20:47:05'),
(61, 'scardflasher2', 'Pengurangan Saldo', 1400, 'Order ID 7876380 Produk PPOB', '2024-08-13', '20:51:55'),
(62, 'maranzano', 'Pengurangan Saldo', 1400, 'Order ID 1591945 Produk PPOB', '2024-08-13', '22:08:48'),
(63, 'maranzano', 'Pengurangan Saldo', 1400, 'Order ID 5516887 Produk PPOB', '2024-08-13', '22:11:34'),
(64, 'scardflasher2', 'Pengurangan Saldo', 1400, 'Order ID 9266915 Produk PPOB', '2024-08-14', '07:25:41'),
(65, 'maranzano', 'Pengurangan Saldo', 1400, 'Order ID 7229705 Produk PPOB', '2024-08-14', '19:09:23'),
(66, 'maranzano', 'Pengurangan Saldo', 1400, 'Order ID 0159472 Produk PPOB', '2024-08-14', '19:11:29'),
(67, 'maranzano', 'Pengurangan Saldo', 1400, 'Order ID 2881724 Produk PPOB', '2024-08-14', '19:13:51'),
(68, 'maranzano', 'Pengurangan Saldo', 1400, 'Order ID 9431753 Produk PPOB', '2024-08-14', '19:16:38'),
(69, 'maranzano', 'Pengurangan Saldo', 1400, 'Order ID 5437981 Produk PPOB', '2024-08-14', '19:18:55'),
(70, 'maranzano', 'Pengurangan Saldo', 1400, 'Order ID 2722756 Produk PPOB', '2024-08-14', '19:38:44'),
(71, 'maranzano', 'Pengurangan Saldo', 1400, 'Order ID 6439069 Produk PPOB', '2024-08-14', '19:50:10'),
(72, 'scardflasher2', 'Pengurangan Saldo', 1400, 'Order ID 4378287 Produk PPOB', '2024-08-14', '20:04:22'),
(73, 'scardflasher2', 'Pengurangan Saldo', 1400, 'Order ID 6662852 Produk PPOB', '2024-08-14', '20:05:14'),
(74, 'scardflasher2', 'Pengurangan Saldo', 1400, 'Order ID 9568300 Produk PPOB', '2024-08-14', '20:09:08'),
(75, 'scardflasher2', 'Pengurangan Saldo', 1400, 'Order ID 6090414 Produk PPOB', '2024-08-14', '20:14:49'),
(76, 'scardflasher2', 'Pengurangan Saldo', 1400, 'Order ID 4075302 Produk PPOB', '2024-08-14', '20:17:03'),
(77, 'scardflasher2', 'Pengurangan Saldo', 1400, 'Order ID 5859705 Produk PPOB', '2024-08-14', '20:27:10'),
(78, 'scardflasher2', 'Pengurangan Saldo', 1400, 'Order ID 7388442 Produk PPOB', '2024-08-14', '20:28:27'),
(79, 'scardflasher2', 'Pengurangan Saldo', 100, 'Order ID 1692258 Produk PPOB', '2024-08-14', '20:40:36'),
(80, 'scardflasher2', 'Pengurangan Saldo', 100, 'Order ID 4510275 Produk PPOB', '2024-08-15', '09:07:45'),
(81, 'scardflasher2', 'Pengurangan Saldo', 100, 'Order ID 2733045 Produk PPOB', '2024-08-15', '18:04:49'),
(82, 'scardflasher2', 'Pengurangan Saldo', 100, 'Order ID 5804510 Produk PPOB', '2024-08-15', '22:48:32'),
(83, 'scardflasher2', 'Pengurangan Saldo', 1400, 'Order ID 1906486 Produk PPOB', '2024-08-15', '22:49:17'),
(84, 'scardflasher2', 'Pengurangan Saldo', 1400, 'Order ID 7660898 Produk PPOB', '2024-08-15', '22:51:46'),
(85, 'maranzano', 'Pengurangan Saldo', 1400, 'Order ID 2406806 Produk PPOB', '2024-08-17', '12:17:21'),
(86, 'maranzano', 'Pengurangan Saldo', 5500, 'Order ID 8160582 Produk PPOB', '2024-08-17', '16:24:37'),
(87, 'scardflasher1', 'Pengurangan Saldo', 100, 'Order ID 2264496 Produk PPOB', '2024-08-17', '16:31:14'),
(88, 'maranzano', 'Pengurangan Saldo', 60500, 'Order ID 3142388 Produk PPOB', '2024-08-17', '20:37:19'),
(89, 'scardflasher2', 'Pengurangan Saldo', 33000, 'Order ID 5760763 Produk PPOB', '2024-08-17', '20:38:15'),
(90, 'maranzano', 'Pengurangan Saldo', 33000, 'Order ID 8020598 Produk Digital', '2024-08-17', '20:42:08'),
(91, 'scardflasher2', 'Pengurangan Saldo', 7000, 'Order ID 7718625 Produk Digital', '2024-08-17', '21:09:55'),
(92, 'scardflasher2', 'Pengurangan Saldo', 5610, 'Order ID 6606684 Produk PPOB', '2024-08-20', '05:43:14'),
(93, 'scardflasher2', 'Pengurangan Saldo', 1671, 'Order ID 0300319 Produk PPOB', '2024-08-20', '12:07:54'),
(94, 'scardflasher2', 'Pengurangan Saldo', 7000, 'Order ID 1748741 Produk Digital', '2024-08-21', '19:15:41'),
(95, 'scardflasher2', 'Pengurangan Saldo', 2644, 'Order ID 6809639 Produk PPOB', '2024-08-23', '13:30:27'),
(96, 'scardflasher2', 'Pengurangan Saldo', 4175, 'Order ID 5157530 Produk PPOB', '2024-08-23', '13:32:44'),
(97, 'scardflasher2', 'Pengurangan Saldo', 1671, 'Order ID 4799942 Produk PPOB', '2024-08-23', '13:33:16'),
(98, 'scardflasher2', 'Pengurangan Saldo', 1000353, 'Order ID 2445628 Produk PPOB', '2024-08-23', '14:39:56'),
(99, 'scardflasher2', 'Pengurangan Saldo', 350, 'Order ID 3807816 Produk PPOB', '2024-08-24', '08:31:50'),
(100, 'scardflasher2', 'Pengurangan Saldo', 350, 'Order ID 4535584 Produk PPOB', '2024-08-24', '08:36:01'),
(101, 'scardflasher2', 'Pengurangan Saldo', 350, 'Order ID 0928558 Produk PPOB', '2024-08-24', '09:21:55'),
(102, 'scardflasher2', 'Pengurangan Saldo', 49920, 'Order ID 1339249 Produk PPOB', '2024-08-24', '12:49:57'),
(103, 'scardflasher2', 'Pengurangan Saldo', 350, 'Order ID 7881771 Produk PPOB', '2024-08-26', '07:41:59'),
(104, 'scardflasher2', 'Pengurangan Saldo', 350, 'Order ID 9908954 Produk PPOB', '2024-08-26', '17:40:13'),
(105, 'scardflasher2', 'Pengurangan Saldo', 350, 'Order ID 1538150 Produk PPOB', '2024-08-26', '18:14:44'),
(106, 'scardflasher2', 'Pengurangan Saldo', 5000, 'Order ID 3374187 Produk Digital', '2024-08-31', '08:29:53');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_layanan`
--

CREATE TABLE `kategori_layanan` (
  `id` int(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `tipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data untuk tabel `kategori_layanan`
--

INSERT INTO `kategori_layanan` (`id`, `nama`, `kode`, `tipe`) VALUES
(1, 'Ceir', 'Ceir', 'Digital');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_layanan2`
--

CREATE TABLE `kategori_layanan2` (
  `id` int(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `tipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_layanan3`
--

CREATE TABLE `kategori_layanan3` (
  `id` int(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `tipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `layanan_digital`
--

CREATE TABLE `layanan_digital` (
  `id` int(11) NOT NULL,
  `service_id` varchar(50) NOT NULL,
  `provider_id` varchar(50) NOT NULL,
  `operator` varchar(50) NOT NULL,
  `layanan` text NOT NULL,
  `harga` double NOT NULL,
  `harga_api` double NOT NULL,
  `profit` double NOT NULL,
  `status` enum('Normal','Gangguan') NOT NULL,
  `provider` varchar(50) NOT NULL,
  `tipe` varchar(50) DEFAULT NULL,
  `catatan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data untuk tabel `layanan_digital`
--

INSERT INTO `layanan_digital` (`id`, `service_id`, `provider_id`, `operator`, `layanan`, `harga`, `harga_api`, `profit`, `status`, `provider`, `tipe`, `catatan`) VALUES
(1, 'Status', 'Status', 'Ceir', 'Cek Status', 5000, 3500, 1500, 'Normal', 'Manual', 'Digital', NULL),
(2, 'History', 'History', 'Ceir', 'Cek History', 8500, 6500, 2000, 'Normal', 'Manual', 'Digital', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `layanan_pulsa`
--

CREATE TABLE `layanan_pulsa` (
  `id` int(11) NOT NULL,
  `service_id` text NOT NULL,
  `provider_id` varchar(50) NOT NULL,
  `operator` varchar(50) NOT NULL,
  `layanan` text NOT NULL,
  `harga` double NOT NULL,
  `harga_api` double NOT NULL,
  `profit` double NOT NULL,
  `status` enum('Normal','Gangguan') NOT NULL,
  `provider` varchar(50) NOT NULL,
  `tipe` varchar(50) NOT NULL,
  `catatan` text NOT NULL,
  `jenis` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `layanan_sosmed`
--

CREATE TABLE `layanan_sosmed` (
  `id` int(10) NOT NULL,
  `service_id` int(10) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `layanan` text NOT NULL,
  `catatan` text NOT NULL,
  `min` int(10) NOT NULL,
  `max` int(10) NOT NULL,
  `harga` double NOT NULL,
  `harga_api` double NOT NULL,
  `profit` double NOT NULL,
  `status` enum('Aktif','Tidak Aktif') NOT NULL,
  `provider_id` int(10) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `tipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `layanan_sosmed2`
--

CREATE TABLE `layanan_sosmed2` (
  `id` int(10) NOT NULL,
  `service_id` int(10) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `layanan` text NOT NULL,
  `catatan` text NOT NULL,
  `min` int(10) NOT NULL,
  `max` int(10) NOT NULL,
  `harga` double NOT NULL,
  `harga_api` double NOT NULL,
  `profit` double NOT NULL,
  `status` enum('Aktif','Tidak Aktif') NOT NULL,
  `provider_id` int(10) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `tipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `layanan_sosmed3`
--

CREATE TABLE `layanan_sosmed3` (
  `id` int(10) NOT NULL,
  `service_id` int(10) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `layanan` text NOT NULL,
  `catatan` text NOT NULL,
  `min` int(10) NOT NULL,
  `max` int(10) NOT NULL,
  `harga` double NOT NULL,
  `harga_api` double NOT NULL,
  `profit` double NOT NULL,
  `status` enum('Aktif','Tidak Aktif') NOT NULL,
  `provider_id` int(10) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `tipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `log`
--

CREATE TABLE `log` (
  `id` int(4) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `aksi` enum('Login','Logout') NOT NULL,
  `ip` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `log`
--

INSERT INTO `log` (`id`, `username`, `aksi`, `ip`, `date`, `time`) VALUES
(83, 'admin', 'Login', '202.67.46.249', '2024-05-26', '09:14:54'),
(84, 'admin', 'Login', '114.5.209.69', '2024-05-26', '13:09:41'),
(85, 'admin', 'Login', '202.67.40.238', '2024-05-26', '14:32:31'),
(86, 'admin', 'Login', '114.5.209.69', '2024-05-26', '14:34:59'),
(87, 'admin', 'Login', '202.67.40.238', '2024-05-26', '14:35:11'),
(88, 'admin', 'Login', '114.5.209.69', '2024-05-26', '14:37:23'),
(89, 'admin', 'Login', '202.67.40.238', '2024-05-26', '14:37:47'),
(90, 'admin', 'Login', '114.5.209.69', '2024-05-26', '14:41:48'),
(91, 'admin', 'Login', '202.67.40.238', '2024-05-26', '14:44:34'),
(92, 'admin', 'Login', '114.5.217.12', '2024-05-26', '17:17:08'),
(93, 'admin', 'Login', '116.206.40.59', '2024-05-26', '17:58:15'),
(94, 'admin', 'Login', '103.142.255.67', '2024-05-26', '20:52:08'),
(95, 'admin', 'Login', '114.5.209.19', '2024-05-27', '14:12:31'),
(96, 'admin', 'Login', '202.67.40.25', '2024-05-27', '14:29:08'),
(97, 'admin', 'Login', '202.67.40.25', '2024-05-27', '14:38:38'),
(98, 'admin', 'Login', '114.5.209.19', '2024-05-27', '14:50:37'),
(99, 'admin', 'Login', '202.67.40.25', '2024-05-27', '15:19:19'),
(100, 'admin', 'Login', '202.67.40.12', '2024-05-30', '19:15:30'),
(101, 'admin', 'Login', '202.67.40.241', '2024-05-31', '20:11:50'),
(102, 'admin', 'Login', '202.67.40.241', '2024-05-31', '20:20:08'),
(103, 'admin', 'Login', '114.5.223.215', '2024-06-20', '12:47:38'),
(104, 'admin', 'Login', '120.188.79.227', '2024-06-20', '21:09:09'),
(105, 'admin', 'Login', '114.5.103.170', '2024-06-29', '08:34:31'),
(106, 'scardflasher', 'Login', '120.188.75.198', '2024-07-07', '22:01:52'),
(107, 'scardflasher2', 'Login', '36.82.13.203', '2024-08-13', '15:55:29'),
(108, 'scardflasher2', 'Login', '36.82.13.203', '2024-08-13', '18:15:36'),
(109, 'maranzano', 'Login', '114.10.136.161', '2024-08-13', '18:54:12'),
(110, 'scardflasher2', 'Login', '114.5.104.239', '2024-08-13', '20:44:56'),
(111, 'maranzano', 'Login', '114.10.136.161', '2024-08-13', '22:05:47'),
(112, 'scardflasher2', 'Login', '180.248.21.64', '2024-08-14', '07:23:51'),
(113, 'maranzano', 'Login', '180.242.233.97', '2024-08-14', '18:54:18'),
(114, 'scardflasher2', 'Login', '180.248.21.64', '2024-08-14', '20:04:01'),
(115, 'maranzano', 'Logout', '114.10.137.78', '2024-08-14', '20:10:45'),
(116, 'Scardflasher2', 'Login', '114.10.137.78', '2024-08-14', '20:11:14'),
(117, 'scardflasher2', 'Login', '180.248.21.64', '2024-08-14', '20:26:50'),
(118, 'maranzano', 'Login', '114.10.137.78', '2024-08-14', '20:30:55'),
(119, 'scardflasher2', 'Login', '180.248.21.64', '2024-08-14', '20:48:14'),
(120, 'scardflasher2', 'Login', '180.248.21.64', '2024-08-14', '21:19:47'),
(121, 'scardflasher2', 'Login', '180.248.21.64', '2024-08-15', '07:09:40'),
(122, 'scardflasher2', 'Login', '180.248.21.64', '2024-08-15', '07:50:01'),
(123, 'scardflasher2', 'Login', '125.163.142.20', '2024-08-15', '08:51:20'),
(124, 'scardflasher2', 'Login', '120.188.78.215', '2024-08-15', '18:04:25'),
(125, 'scardflasher2', 'Login', '114.5.222.172', '2024-08-15', '18:24:34'),
(126, 'scardflasher2', 'Login', '114.5.110.128', '2024-08-15', '22:18:22'),
(127, 'scardflasher2', 'Login', '114.5.110.189', '2024-08-16', '12:30:46'),
(128, 'scardflasher2', 'Login', '114.5.110.169', '2024-08-16', '17:13:52'),
(129, 'scardflasher2', 'Login', '120.188.74.219', '2024-08-16', '19:08:49'),
(130, 'maranzano', 'Login', '180.242.233.97', '2024-08-16', '23:34:22'),
(131, 'maranzano', 'Login', '180.242.233.97', '2024-08-17', '00:29:25'),
(132, 'maranzano', 'Login', '180.242.233.97', '2024-08-17', '10:23:41'),
(133, 'scardflasher2', 'Login', '120.188.79.237', '2024-08-17', '12:54:18'),
(134, 'scardflasher2', 'Login', '180.248.17.77', '2024-08-17', '14:12:13'),
(135, 'maranzano', 'Login', '180.242.233.97', '2024-08-17', '15:51:58'),
(136, 'scardflasher2', 'Login', '180.248.24.0', '2024-08-17', '16:25:40'),
(137, 'scardflasher2', 'Logout', '180.248.24.0', '2024-08-17', '16:27:30'),
(138, 'scardflasher1', 'Login', '180.248.24.0', '2024-08-17', '16:28:07'),
(139, 'scardflasher2', 'Login', '180.248.24.0', '2024-08-17', '16:28:26'),
(140, 'scardflasher2', 'Logout', '180.248.24.0', '2024-08-17', '16:29:20'),
(141, 'scardflasher1', 'Login', '180.248.24.0', '2024-08-17', '16:30:40'),
(142, 'scardflasher1', 'Logout', '180.248.24.0', '2024-08-17', '16:33:28'),
(143, 'Scardflasher2', 'Login', '180.248.24.0', '2024-08-17', '16:33:39'),
(144, 'maranzano', 'Login', '180.242.233.97', '2024-08-17', '19:46:06'),
(145, 'scardflasher2', 'Login', '114.5.105.235', '2024-08-17', '20:04:43'),
(146, 'maranzano', 'Login', '114.10.137.162', '2024-08-17', '20:36:55'),
(147, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-17', '22:14:50'),
(148, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-17', '23:13:59'),
(149, 'maranzano', 'Login', '180.242.233.97', '2024-08-17', '23:58:17'),
(150, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-18', '05:30:13'),
(151, 'scardflasher2', 'Login', '114.5.104.192', '2024-08-18', '08:34:49'),
(152, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-18', '17:22:57'),
(153, 'maranzano', 'Login', '114.10.137.30', '2024-08-18', '17:32:20'),
(154, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-19', '13:29:06'),
(155, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-19', '17:25:37'),
(156, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-19', '18:30:38'),
(157, 'scardflasher2', 'Login', '114.5.103.170', '2024-08-19', '18:56:34'),
(158, 'maranzano', 'Login', '180.242.232.173', '2024-08-20', '03:22:40'),
(159, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-20', '05:28:56'),
(160, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-20', '05:35:28'),
(161, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-20', '05:39:04'),
(162, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-20', '11:48:17'),
(163, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-20', '11:52:10'),
(164, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-20', '11:58:18'),
(165, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-20', '12:29:14'),
(166, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-20', '15:12:25'),
(167, 'scardflasher2', 'Login', '180.248.31.132', '2024-08-21', '06:37:15'),
(168, 'scardflasher2', 'Login', '114.5.104.16', '2024-08-21', '19:15:31'),
(169, 'scardflasher2', 'Login', '114.5.110.185', '2024-08-22', '10:10:23'),
(170, 'scardflasher2', 'Login', '114.5.110.137', '2024-08-22', '14:52:19'),
(171, 'scardflasher2', 'Login', '120.188.79.220', '2024-08-22', '21:22:12'),
(172, 'maranzano', 'Login', '180.242.233.242', '2024-08-22', '22:19:30'),
(173, 'scardflasher2', 'Login', '114.5.103.129', '2024-08-23', '07:16:11'),
(174, 'scardflasher2', 'Login', '114.5.105.249', '2024-08-23', '12:43:41'),
(175, 'scardflasher2', 'Login', '114.5.105.249', '2024-08-23', '13:29:44'),
(176, 'maranzano', 'Login', '180.242.233.242', '2024-08-23', '14:21:32'),
(177, 'scardflasher2', 'Login', '120.188.79.149', '2024-08-23', '14:39:41'),
(178, 'scardflasher2', 'Login', '114.5.222.191', '2024-08-23', '17:04:14'),
(179, 'scardflasher2', 'Login', '114.5.103.138', '2024-08-24', '08:28:08'),
(180, 'scardflasher2', 'Login', '114.5.103.138', '2024-08-24', '08:57:31'),
(181, 'scardflasher2', 'Login', '114.5.104.134', '2024-08-24', '10:31:57'),
(182, 'scardflasher2', 'Login', '114.5.111.251', '2024-08-24', '12:48:33'),
(183, 'scardflasher2', 'Login', '120.188.79.152', '2024-08-24', '14:26:14'),
(184, 'admin', 'Login', '45.8.25.64', '2024-08-25', '02:53:13'),
(185, 'scardflasher2', 'Login', '114.5.223.173', '2024-08-26', '07:41:27'),
(186, 'maranzano', 'Login', '180.242.233.28', '2024-08-26', '17:29:29'),
(187, 'scardflasher2', 'Login', '114.5.102.75', '2024-08-26', '17:38:51'),
(188, 'scardflasher2', 'Login', '114.5.102.120', '2024-08-27', '10:09:20'),
(189, 'scardflasher1', 'Login', '114.5.222.187', '2024-08-27', '12:20:26'),
(190, 'scardflasher1', 'Logout', '114.5.222.187', '2024-08-27', '12:20:43'),
(191, 'scardflasher2', 'Login', '114.5.222.187', '2024-08-27', '12:20:50'),
(192, 'scardflasher2', 'Login', '120.188.74.239', '2024-08-27', '14:20:36'),
(193, 'scardflasher2', 'Login', '120.188.78.239', '2024-08-27', '16:11:34'),
(194, 'scardflasher2', 'Login', '114.5.102.191', '2024-08-27', '19:23:12'),
(195, 'scardflasher2', 'Login', '114.5.104.120', '2024-08-28', '05:38:57'),
(196, 'scardflasher2', 'Login', '114.5.103.147', '2024-08-28', '10:56:12'),
(197, 'scardflasher2', 'Login', '120.188.74.165', '2024-08-28', '16:32:10'),
(198, 'scardflasher2', 'Login', '114.5.223.242', '2024-08-28', '21:17:11'),
(199, 'scardflasher2', 'Login', '120.188.74.190', '2024-08-29', '05:01:47'),
(200, 'scardflasher2', 'Login', '114.5.105.184', '2024-08-29', '11:38:12'),
(201, 'scardflasher2', 'Login', '114.5.102.105', '2024-08-29', '16:45:49'),
(202, 'scardflasher2', 'Login', '120.188.78.243', '2024-08-29', '18:43:11'),
(203, 'scardflasher2', 'Login', '120.188.78.243', '2024-08-29', '19:32:46'),
(204, 'scardflasher2', 'Login', '114.5.111.133', '2024-08-29', '20:46:09'),
(205, 'scardflasher2', 'Login', '114.5.104.179', '2024-08-30', '05:02:18'),
(206, 'Scardflasher2', 'Login', '180.242.233.28', '2024-08-30', '15:15:03'),
(207, 'scardflasher2', 'Login', '114.5.111.193', '2024-08-30', '15:43:14'),
(208, 'Scardflasher2', 'Login', '180.242.233.28', '2024-08-30', '16:09:15'),
(209, 'scardflasher2', 'Login', '114.5.111.193', '2024-08-30', '16:10:03'),
(210, 'Scardflasher2', 'Login', '114.10.137.38', '2024-08-30', '16:13:20'),
(211, 'scardflasher2', 'Login', '114.5.222.227', '2024-08-30', '18:24:24'),
(212, 'scardflasher2', 'Login', '114.5.110.224', '2024-08-30', '21:27:53'),
(213, 'scardflasher2', 'Login', '114.5.103.230', '2024-08-31', '06:51:37'),
(214, 'scardflasher2', 'Login', '114.5.103.248', '2024-08-31', '07:27:11'),
(215, 'scardflasher2', 'Logout', '114.5.103.248', '2024-08-31', '08:16:11'),
(216, 'scardflasher2', 'Login', '114.5.103.248', '2024-08-31', '08:16:52'),
(217, 'Scardflasher2', 'Login', '114.10.152.115', '2024-08-31', '08:33:49'),
(218, 'scardflasher2', 'Login', '114.5.103.248', '2024-08-31', '08:45:53');

-- --------------------------------------------------------

--
-- Struktur dari tabel `metode_depo`
--

CREATE TABLE `metode_depo` (
  `id` int(255) NOT NULL,
  `tipe` enum('Pulsa','Bank','EMoney','EPayment','ECurrency') NOT NULL,
  `provider` varchar(255) NOT NULL,
  `jalur` enum('Auto','Manual') NOT NULL,
  `nama` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `keterangan` varchar(250) NOT NULL,
  `tujuan` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `metode_depo`
--

INSERT INTO `metode_depo` (`id`, `tipe`, `provider`, `jalur`, `nama`, `rate`, `keterangan`, `tujuan`) VALUES
(1, 'EPayment', 'PAYPAL', 'Auto', 'PAYPAL Konfirmasi Otomatis', '12000', 'ON', 'GANTI'),
(2, 'EMoney', 'GOPAY', 'Auto', 'GOPAY Konfirmasi Otomatis', '1', 'ON', 'GANTI'),
(3, 'EMoney', 'OVO', 'Auto', 'OVO Konfirmasi Otomatis', '1', 'ON', 'GANTI'),
(4, 'EMoney', 'DANA', 'Auto', 'DANA Konfirmasi Otomatis', '1', 'ON', 'GANTI'),
(5, 'Pulsa', 'TSEL', 'Auto', 'TSEL Konfirmasi Otomatis', '0.81', 'ON', 'GANTI'),
(6, 'Bank', 'BNI', 'Auto', 'BNI Konfirmasi Otomatis', '1', 'ON', 'GANTI'),
(7, 'Bank', 'BRI', 'Auto', 'BRI Konfirmasi Otomatis', '1', 'ON', 'GANTI'),
(8, 'Bank', 'BCA', 'Auto', 'BCA Konfirmasi Otomatis', '1', 'ON', 'GANTI'),
(9, 'Bank', 'BNI', 'Auto', 'BNI Konfirmasi Otomatis', '1', 'ON', 'GANTI');

-- --------------------------------------------------------

--
-- Struktur dari tabel `oke`
--

CREATE TABLE `oke` (
  `id` int(11) NOT NULL,
  `member_id` text NOT NULL,
  `password` text NOT NULL,
  `pin` text NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian_digital`
--

CREATE TABLE `pembelian_digital` (
  `id` int(10) NOT NULL,
  `oid` varchar(50) NOT NULL,
  `provider_oid` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `layanan` varchar(100) NOT NULL,
  `harga` double NOT NULL,
  `profit` varchar(50) NOT NULL,
  `target` varchar(50) NOT NULL,
  `no_meter` varchar(50) NOT NULL,
  `keterangan` text NOT NULL,
  `status` enum('Pending','Processing','Error','Partial','Success') NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `place_from` varchar(50) NOT NULL DEFAULT 'Website',
  `provider` varchar(100) NOT NULL,
  `refund` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data untuk tabel `pembelian_digital`
--

INSERT INTO `pembelian_digital` (`id`, `oid`, `provider_oid`, `user`, `layanan`, `harga`, `profit`, `target`, `no_meter`, `keterangan`, `status`, `date`, `time`, `place_from`, `provider`, `refund`) VALUES
(16, '3374187', '3374187', 'scardflasher2', 'Cek Status', 5000, '1500', '082132687740', '', 'No	Date	IMEI	IMSI	Action	Note\r\n1	2024-08-25 12:09:29	35642410163876		remove_roamer	auto-remove-operation\r\n2	2024-05-27 12:09:28	35642410163876			\r\n3	2024-05-27 12:09:28	35642410163876		add_roamer	Add Roamer by Digipos\r\n4	2024-05-26 13:40:10	35642410163876		remove_roamer	auto-remove-operation\r\n5	2024-02-26 13:40:06	35642410163876			\r\n6	2024-02-26 13:40:06	35642410163876		add_roamer	inbound roamer\r\n7	2024-02-24 22:57:03	35642410163876		remove_roamer	auto-remove-operation\r\n8	2023-11-26 22:57:00	35642410163876			\r\n9	2023-11-26 22:57:00	35642410163876			\r\n10	2023-11-26 22:57:00	35642410163876			\r\n11	2023-11-26 22:57:00	35642410163876			\r\n12	2023-11-26 22:57:00	35642410163876		add_roamer	WNA\r\n13	2023-11-22 19:54:39	35642410163876		remove_roamer	auto-remove-operation\r\n14	2023-08-24 19:54:36	35642410163876			\r\n15	2023-08-24 19:54:36	35642410163876		add_roamer	Registrasi WNA\r\n16	2023-08-24 19:54:29	35642410163876		remove_roamer	Remove Roamer di Registrasi WNA\r\n17	2023-08-24 19:54:24	35642410163876		add_roamer	Registrasi WNA\r\n18	2023-06-14 10:36:14	35642410163876			\r\n19	2023-06-14 10:36:14	35642410163876		add_roamer	Registrasi WNA\r\n20	2023-05-25 14:33:14	35642410163876		remove_roamer	auto-remove-operation\r\n21	2023-02-24 14:33:12	35642410163876			\r\n22	2023-02-24 14:33:12	35642410163876		add_roamer	Registrasi WNA\r\n23	2022-10-22 23:01:18	35642410163876		remove_roamer	auto-remove-operation\r\n24	2022-07-24 23:01:15	35642410163876			\r\n25	2022-07-24 23:01:15	35642410163876		add_roamer	ADD sampai sini', 'Pending', '2024-08-31', '08:29:53', 'Website', 'Manual', '0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian_pulsa`
--

CREATE TABLE `pembelian_pulsa` (
  `id` int(10) NOT NULL,
  `oid` varchar(50) NOT NULL,
  `provider_oid` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `layanan` varchar(100) NOT NULL,
  `harga` double NOT NULL,
  `profit` varchar(50) NOT NULL,
  `target` varchar(50) NOT NULL,
  `no_meter` varchar(50) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `status` enum('Pending','Processing','Error','Partial','Success') NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `place_from` varchar(50) NOT NULL DEFAULT 'Website',
  `provider` varchar(100) NOT NULL,
  `refund` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian_sosmed`
--

CREATE TABLE `pembelian_sosmed` (
  `id` int(10) NOT NULL,
  `oid` varchar(50) NOT NULL,
  `provider_oid` varchar(50) NOT NULL,
  `user` varchar(100) NOT NULL,
  `layanan` varchar(100) NOT NULL,
  `target` text NOT NULL,
  `jumlah` int(10) NOT NULL,
  `remains` varchar(10) NOT NULL,
  `start_count` varchar(10) NOT NULL,
  `harga` double NOT NULL,
  `profit` double NOT NULL,
  `status` enum('Pending','Processing','In progress','Error','Partial','Success') NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `provider` varchar(100) NOT NULL,
  `place_from` enum('Website','API') NOT NULL,
  `refund` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesan_tiket`
--

CREATE TABLE `pesan_tiket` (
  `id` int(10) NOT NULL,
  `id_tiket` int(10) NOT NULL,
  `pengirim` enum('Member','Admin') NOT NULL,
  `user` varchar(50) NOT NULL,
  `pesan` text NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `update_terakhir` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesan_tsel`
--

CREATE TABLE `pesan_tsel` (
  `id` int(11) NOT NULL,
  `isi` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_swedish_ci NOT NULL,
  `status` enum('UNREAD','READ') NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `provider`
--

CREATE TABLE `provider` (
  `id` int(10) NOT NULL,
  `code` varchar(50) NOT NULL,
  `link` varchar(100) NOT NULL,
  `api_key` varchar(100) NOT NULL,
  `api_id` varchar(50) NOT NULL,
  `secret_key` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data untuk tabel `provider`
--

INSERT INTO `provider` (`id`, `code`, `link`, `api_key`, `api_id`, `secret_key`) VALUES
(2, 'ariepulsa', 'https://ariepulsa.com/api/', 'WlB0Ujx9c9Gfq2QAaP49pNW25Pc9FvoJ', '', ''),
(3, 'WAGATEWAY', 'https://www.home.scardwaget.my.id', 'N6dhg8C2S5RWT1FBERTCOB1JcwccVr', '628982765556', ''),
(4, 'Manual ', ' ', ' ', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat_transfer`
--

CREATE TABLE `riwayat_transfer` (
  `id` int(10) NOT NULL,
  `pengirim` varchar(50) NOT NULL,
  `penerima` varchar(50) NOT NULL,
  `jumlah` double NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `setting_profit`
--

CREATE TABLE `setting_profit` (
  `id` int(11) NOT NULL,
  `kategori` enum('WEBSITE','API') NOT NULL,
  `tipe` enum('Sosial Media','PPOB','Digital') NOT NULL,
  `harga` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `setting_profit`
--

INSERT INTO `setting_profit` (`id`, `kategori`, `tipe`, `harga`) VALUES
(1, 'WEBSITE', 'Sosial Media', '1.2'),
(2, 'API', 'Sosial Media', '1.17'),
(3, 'WEBSITE', 'PPOB', '1.1'),
(4, 'API', 'PPOB', '1.08'),
(5, 'WEBSITE', 'Digital', '1.1'),
(6, 'API', 'Digital', '1.07');

-- --------------------------------------------------------

--
-- Struktur dari tabel `setting_web`
--

CREATE TABLE `setting_web` (
  `id` int(11) NOT NULL,
  `short_title` text NOT NULL,
  `title` text NOT NULL,
  `wa_notif` text NOT NULL,
  `deskripsi_web` text NOT NULL,
  `kontak_utama` text NOT NULL,
  `alamat` text NOT NULL,
  `url_alamat` text NOT NULL,
  `facebook` text NOT NULL,
  `url_facebook` text NOT NULL,
  `instagram` text NOT NULL,
  `url_instagram` text NOT NULL,
  `whatsapp` text NOT NULL,
  `url_whatsapp` text NOT NULL,
  `youtube` text NOT NULL,
  `url_youtube` text NOT NULL,
  `twitter` text NOT NULL,
  `url_twitter` text NOT NULL,
  `email` text NOT NULL,
  `url_email` text NOT NULL,
  `jam_kerja` text NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `setting_web`
--

INSERT INTO `setting_web` (`id`, `short_title`, `title`, `wa_notif`, `deskripsi_web`, `kontak_utama`, `alamat`, `url_alamat`, `facebook`, `url_facebook`, `instagram`, `url_instagram`, `whatsapp`, `url_whatsapp`, `youtube`, `url_youtube`, `twitter`, `url_twitter`, `email`, `url_email`, `jam_kerja`, `date`, `time`) VALUES
(1, 'roamerimei.xyz', 'roamerimei.xyz - Panel imei Terbaik', '628982765556', 'Distributor operator H2H . Provider terbaik dan terlengkap.', ' ', 'Indonesia', '', '', '', '', '', '', '', '', '', '', '', 'Help@roamerimei.xyz', 'mailto:help@roamerimei.xyz', '10:00 - 21:00 WIB', '2019-01-03', '16:06:10');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tiket`
--

CREATE TABLE `tiket` (
  `id` int(10) NOT NULL,
  `user` varchar(50) NOT NULL,
  `subjek` varchar(250) NOT NULL,
  `pesan` text NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `update_terakhir` datetime NOT NULL,
  `status` enum('Pending','Responded','Waiting','Closed') NOT NULL,
  `this_user` int(1) NOT NULL,
  `this_admin` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `saldo` int(10) NOT NULL,
  `pemakaian_saldo` double NOT NULL,
  `level` enum('Member','Agen','Admin','Developers','Reseller') NOT NULL,
  `status` enum('Aktif','Tidak Aktif') NOT NULL,
  `api_key` varchar(100) NOT NULL,
  `uplink` varchar(100) NOT NULL,
  `terdaftar` datetime NOT NULL,
  `update_nama` int(1) NOT NULL,
  `random_kode` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `no_hp`, `username`, `password`, `saldo`, `pemakaian_saldo`, `level`, `status`, `api_key`, `uplink`, `terdaftar`, `update_nama`, `random_kode`) VALUES
(6, 'SCARDFLASHER', 'slot96122@gmail.com', '087761891018', 'admin', '$2y$10$dqT2A70ptBe6S41SaOdmhuF6VQ3IqtMAwpVxUDU2z3F3ZgJ2t2LhW', 99888999, 111000, 'Developers', 'Aktif', 'VeQNy1eD9NbTMF28io6QAUelD2u8rkHA', 'Pendaftaran Gratis', '2024-05-26 09:14:48', 0, ''),
(7, 'SETEVEN SUGIARTO', 'sugiartosteven90@gmail.com', '08982765556', 'scardflasher', '$2y$10$AbjJixNlwPcu0XvpgvsszugbKDfXU7BulpsyJgnaENgp69DGXQ1wC', 999999, 0, 'Developers', 'Aktif', 'BUA9HeWphPb4126wUU8kZZUcTXzx726v', 'Pendaftaran Gratis', '2024-07-07 22:01:38', 0, ''),
(8, 'SETEVEN SUGIARTO', 'sugiartosteve0@gmail.com', '087761891018', 'scardflasher2', '$2y$10$CWULYNqVqTaF1JqyVTTaIuz1Jog58wp4cFAWfH34WkQfcTYvy3xAq', 98862655, 1137344, 'Developers', 'Aktif', 'S6hFyk61751vS3UmFJSkVEQs8cTF7elj', 'Pendaftaran Gratis', '2024-08-13 15:55:24', 0, ''),
(9, 'Salvatore Maranzano', 'sugiartosteve0@gmail.com', '087761891018', 'maranzano', '$2a$12$iN6Ri50T9QsdVljMjS23J.77me45qtC92rnIlXcy4kwY85fuvehEy', 99884199, 115800, 'Developers', 'Aktif', 'S6hFyk61751vS3UmFJSkVEQs8cTF7elj', 'Pendaftaran Gratis', '2024-08-13 15:55:24', 0, ''),
(10, 'SETEVEN SUGIARTO', 'sugiartostevxe0@gmail.com', '0877618910188', 'scardflasher1', '$2y$10$pmCtjmUO6Yoeb8Zpg6iO3.U8aEcpAiHBRtbi4IrT.0gM3ssn6CPs.', 899900, 100, 'Developers', 'Aktif', 'wblo8B5rYknqr7QfjuHv0JAxNjHtVaFJ', 'Pendaftaran Gratis', '2024-08-17 16:28:00', 0, '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users_token`
--

CREATE TABLE `users_token` (
  `id` int(11) NOT NULL,
  `username` varchar(80) NOT NULL,
  `tokenuser` varchar(80) NOT NULL,
  `timemodified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `users_token`
--

INSERT INTO `users_token` (`id`, `username`, `tokenuser`, `timemodified`) VALUES
(14, 'admin', 'lCERIjAer5', '2024-08-24 19:53:13'),
(15, 'scardflasher', 'UD555sIrMk', '2024-07-07 15:01:52'),
(18, 'maranzano', 'QIpdlYDcIG', '2024-08-26 10:29:30'),
(23, 'scardflasher2', '0DRaeRnZaS', '2024-08-31 01:45:53');

-- --------------------------------------------------------

--
-- Struktur dari tabel `voucher`
--

CREATE TABLE `voucher` (
  `id` int(10) NOT NULL,
  `voucher` varchar(50) NOT NULL,
  `saldo` varchar(250) NOT NULL,
  `status` enum('active','sudah di redeem') NOT NULL,
  `user` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `deposit`
--
ALTER TABLE `deposit`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `deposit_bank`
--
ALTER TABLE `deposit_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `deposit_emoney`
--
ALTER TABLE `deposit_emoney`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `deposit_epayment`
--
ALTER TABLE `deposit_epayment`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `deposit_tsel`
--
ALTER TABLE `deposit_tsel`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `deposit_voucher`
--
ALTER TABLE `deposit_voucher`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `edit_sn`
--
ALTER TABLE `edit_sn`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `halaman`
--
ALTER TABLE `halaman`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `harga_pendaftaran`
--
ALTER TABLE `harga_pendaftaran`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `history_saldo`
--
ALTER TABLE `history_saldo`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kategori_layanan`
--
ALTER TABLE `kategori_layanan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kategori_layanan2`
--
ALTER TABLE `kategori_layanan2`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kategori_layanan3`
--
ALTER TABLE `kategori_layanan3`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `layanan_digital`
--
ALTER TABLE `layanan_digital`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `layanan_pulsa`
--
ALTER TABLE `layanan_pulsa`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `layanan_sosmed`
--
ALTER TABLE `layanan_sosmed`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `layanan_sosmed2`
--
ALTER TABLE `layanan_sosmed2`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `layanan_sosmed3`
--
ALTER TABLE `layanan_sosmed3`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `metode_depo`
--
ALTER TABLE `metode_depo`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `oke`
--
ALTER TABLE `oke`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pembelian_digital`
--
ALTER TABLE `pembelian_digital`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pembelian_pulsa`
--
ALTER TABLE `pembelian_pulsa`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pembelian_sosmed`
--
ALTER TABLE `pembelian_sosmed`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pesan_tiket`
--
ALTER TABLE `pesan_tiket`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pesan_tsel`
--
ALTER TABLE `pesan_tsel`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `provider`
--
ALTER TABLE `provider`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `riwayat_transfer`
--
ALTER TABLE `riwayat_transfer`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `setting_profit`
--
ALTER TABLE `setting_profit`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `setting_web`
--
ALTER TABLE `setting_web`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tiket`
--
ALTER TABLE `tiket`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users_token`
--
ALTER TABLE `users_token`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `voucher`
--
ALTER TABLE `voucher`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `berita`
--
ALTER TABLE `berita`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `deposit`
--
ALTER TABLE `deposit`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `deposit_bank`
--
ALTER TABLE `deposit_bank`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `deposit_emoney`
--
ALTER TABLE `deposit_emoney`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `deposit_epayment`
--
ALTER TABLE `deposit_epayment`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `deposit_tsel`
--
ALTER TABLE `deposit_tsel`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `deposit_voucher`
--
ALTER TABLE `deposit_voucher`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `edit_sn`
--
ALTER TABLE `edit_sn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `halaman`
--
ALTER TABLE `halaman`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `harga_pendaftaran`
--
ALTER TABLE `harga_pendaftaran`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `history_saldo`
--
ALTER TABLE `history_saldo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT untuk tabel `kategori_layanan`
--
ALTER TABLE `kategori_layanan`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `kategori_layanan2`
--
ALTER TABLE `kategori_layanan2`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `kategori_layanan3`
--
ALTER TABLE `kategori_layanan3`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `layanan_digital`
--
ALTER TABLE `layanan_digital`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `layanan_pulsa`
--
ALTER TABLE `layanan_pulsa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `layanan_sosmed`
--
ALTER TABLE `layanan_sosmed`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `layanan_sosmed2`
--
ALTER TABLE `layanan_sosmed2`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `layanan_sosmed3`
--
ALTER TABLE `layanan_sosmed3`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `log`
--
ALTER TABLE `log`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=219;

--
-- AUTO_INCREMENT untuk tabel `metode_depo`
--
ALTER TABLE `metode_depo`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `oke`
--
ALTER TABLE `oke`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pembelian_digital`
--
ALTER TABLE `pembelian_digital`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `pembelian_pulsa`
--
ALTER TABLE `pembelian_pulsa`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pembelian_sosmed`
--
ALTER TABLE `pembelian_sosmed`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pesan_tiket`
--
ALTER TABLE `pesan_tiket`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pesan_tsel`
--
ALTER TABLE `pesan_tsel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `provider`
--
ALTER TABLE `provider`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `riwayat_transfer`
--
ALTER TABLE `riwayat_transfer`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `setting_profit`
--
ALTER TABLE `setting_profit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `setting_web`
--
ALTER TABLE `setting_web`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tiket`
--
ALTER TABLE `tiket`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `users_token`
--
ALTER TABLE `users_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT untuk tabel `voucher`
--
ALTER TABLE `voucher`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
